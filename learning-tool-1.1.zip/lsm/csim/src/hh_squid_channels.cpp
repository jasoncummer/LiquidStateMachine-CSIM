#include "hh_squid_channels.h"

double *HH_h_Gate::C1=0;
double *HH_h_Gate::C2=0;

double *HH_m_Gate::C1=0;
double *HH_m_Gate::C2=0;

double *HH_n_Gate::C1=0;
double *HH_n_Gate::C2=0;
