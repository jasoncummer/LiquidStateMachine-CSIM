/*! \file advanceable.cpp
**  \brief Implementation of class Advancable. Is empty because Advancable is a "pure virtual" class.
**
*/

#include "advanceable.h"
