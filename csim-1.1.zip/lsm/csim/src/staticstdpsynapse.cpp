/*! \file staticstdpsynapse.cpp
**  \brief Implementation of StaticStdpSynapse
*/

#include "staticstdpsynapse.h"
